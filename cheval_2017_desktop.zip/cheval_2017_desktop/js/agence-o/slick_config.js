/**!
	Swap blocks
	on ready

	@contributors: Author names Agence-o
	@date-created: 2016-07-21
	@last-update: 2016-07-21
 */
 
;(function($) {

	$(document).ready(function () {
		$('.front .gal-main-content.gallery-js.gal-horizontale').slick({
			infinite: true,
			slidesToShow: 5,
			slidesToScroll: 2,
			arrows:true

	});
	});

})(jQuery);
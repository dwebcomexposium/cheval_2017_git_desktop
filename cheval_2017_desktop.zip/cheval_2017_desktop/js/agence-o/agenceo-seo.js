/**!
 Agence'O Youtube video wall
 Create a Youtube video wall with Youtube API scripts

 @contributors: Nicolas Bugeja (Agence'O), Guillaume Bouillon (Agence'O), Yevhenii Tretiak
 @version 1.2
 @date-created: 2016-08-22
 @last-update: 2016-08-22
 */
(function ($) {

    $('.site-footer .edito .inside').find('p,h4').wrapAll('<div class="footer-txt" />');

})(jQuery);